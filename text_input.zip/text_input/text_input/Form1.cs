namespace text_input
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text.ToLower();

            if (string.IsNullOrEmpty(inputText))
            {
                label1.Text = "Nic nebylo zad�no.";
                return;
            }

            if (inputText.All(char.IsDigit))
            {
                label1.Text = "Zad�no ��slo.";
            }
            else if (inputText.Length == 1 && "aeiouy".Contains(inputText))
            {
                label1.Text = "Zad�na samohl�ska.";
            }
            else if (inputText.All(char.IsLetter))
            {
                label1.Text = "Zad�na p�smena.";
            }
            else
            {
                label1.Text = "Zad�n nezn�m� typ vstupu.";
            }
        }
    }
}